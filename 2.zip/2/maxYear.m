function [maximum_CO2_year] = maxYear()
    %Finding the year that atmospheric CO2 reach its maximum
    




end
